import time
import matplotlib.pyplot as plt

def no_valido(fila, col, reinas):
    for r in range(fila):
        if col == reinas[r] or abs(col - reinas[r]) == abs(fila - r):
            return False
    return True

def imprimir_tablero(reinas):
    for fila in range(len(reinas)):
        line = ""
        for col in range(len(reinas)):
            if col == reinas[fila]:
                line += "Q "
            else:
                line += ". "
        print(line)
    print("\n")

def lugar_reina(fila, reinas, n):
    if fila == n:
        imprimir_tablero(reinas)
        return 1
    else:
        sol_total = 0
        for col in range(n):
            if no_valido(fila, col, reinas):
                reinas[fila] = col
                sol_total += lugar_reina(fila+1, reinas, n)
        return sol_total

def n_reinas(n):
    reinas = [-1] * n
    fila = 0
    return lugar_reina(fila, reinas, n)

# Medir el tiempo de ejecución
start_time = time.time()
soluciones = n_reinas(8)
end_time = time.time()

print("Número total de soluciones:", soluciones)
print("Tiempo de ejecución:", end_time - start_time, "segundos")

# Visualización gráfica
plt.bar(["Soluciones", "Tiempo de ejecución"], [soluciones, end_time - start_time])
plt.ylabel("Valor")
plt.title("Desempeño del algoritmo de N reinas")
plt.show()
