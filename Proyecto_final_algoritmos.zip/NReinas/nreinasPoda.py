import tkinter as tk
from tkinter import ttk
import time
import matplotlib.pyplot as plt

def no_valido(fila, col, reinas):
    for r in range(fila):
        if col == reinas[r] or abs(col - reinas[r]) == abs(fila - r):
            return False
    return True

def imprimir_tablero(reinas):
    for fila in range(len(reinas)):
        line = ""
        for col in range(len(reinas)):
            if col == reinas[fila]:
                line += "Q "
            else:
                line += ". "
        print(line)
    print("\n")

def lugar_reina(fila, reinas, n, alpha, beta):
    if fila == n:
        imprimir_tablero(reinas)
        return 1
    else:
        sol_total = 0
        for col in range(n):
            if no_valido(fila, col, reinas):
                reinas[fila] = col
                sol_total += lugar_reina(fila+1, reinas, n, -beta, -alpha)
                
                # Poda alfa-beta
                alpha = max(alpha, -sol_total)
                if alpha >= beta:
                    break
        return sol_total

class NReinasGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("N-Reinas Solver")

        self.label = tk.Label(root, text="Cantidad de reinas:")
        self.label.pack()

        self.entry = tk.Entry(root)
        self.entry.pack()

        self.solve_button = tk.Button(root, text="Resolver", command=self.solve)
        self.solve_button.pack()

        self.canvas = tk.Canvas(root, width=400, height=400)
        self.canvas.pack()

        self.results_label = tk.Label(root, text="")
        self.results_label.pack()

    def solve(self):
        n = int(self.entry.get())
        reinas = [-1] * n
        fila = 0
        alpha, beta = float('-inf'), float('inf')
        
        start_time = time.time()
        soluciones = self.lugar_reina(fila, reinas, n, alpha, beta)
        end_time = time.time()

        print("Número total de soluciones:", soluciones)
        print("Tiempo de ejecución:", end_time - start_time, "segundos")

        self.results_label.config(text=f"Número de soluciones: {soluciones}\nTiempo de ejecución: {end_time - start_time:.4f} segundos")

        # Visualización gráfica
        self.plot_results(soluciones, end_time - start_time)

    def lugar_reina(self, fila, reinas, n, alpha, beta):
        if fila == n:
            self.imprimir_tablero(reinas)
            return 1
        else:
            sol_total = 0
            for col in range(n):
                if self.no_valido(fila, col, reinas):
                    reinas[fila] = col
                    sol_total += self.lugar_reina(fila+1, reinas, n, -beta, -alpha)

                    # Poda alfa-beta
                    alpha = max(alpha, -sol_total)
                    if alpha >= beta:
                        break
            return sol_total

    def no_valido(self, fila, col, reinas):
        for r in range(fila):
            if col == reinas[r] or abs(col - reinas[r]) == abs(fila - r):
                return False
        return True

    def imprimir_tablero(self, reinas):
        self.canvas.delete("all")
        cell_size = 400 // len(reinas)

        for fila in range(len(reinas)):
            for col in range(len(reinas)):
                x1, y1 = col * cell_size, fila * cell_size
                x2, y2 = x1 + cell_size, y1 + cell_size

                if col == reinas[fila]:
                    self.canvas.create_rectangle(x1, y1, x2, y2, fill="lightgreen")
                    self.canvas.create_text((x1 + x2) // 2, (y1 + y2) // 2, text="Q", font=("Arial", 12, "bold"))
                else:
                    self.canvas.create_rectangle(x1, y1, x2, y2, fill="white", outline="black")

    def plot_results(self, soluciones, tiempo_ejecucion):
        plt.bar(["Soluciones", "Tiempo de ejecución"], [soluciones, tiempo_ejecucion])
        plt.ylabel("Valor")
        plt.title("Desempeño del algoritmo de N reinas")
        plt.show()

if __name__ == "__main__":
    root = tk.Tk()
    app = NReinasGUI(root)
    root.mainloop()
