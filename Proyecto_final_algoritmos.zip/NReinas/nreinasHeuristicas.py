import tkinter as tk
from tkinter import messagebox, ttk
import time
import random
import matplotlib.pyplot as plt

def no_valido(fila, col, reinas):
    for r in range(fila):
        if col == reinas[r] or abs(col - reinas[r]) == abs(fila - r):
            return False
    return True

def imprimir_tablero_text(tablero_text, reinas):
    tablero_text.delete(1.0, tk.END)
    for fila in range(len(reinas)):
        line = ""
        for col in range(len(reinas)):
            if col == reinas[fila]:
                line += "Q "
            else:
                line += ". "
        line += "\n"
        tablero_text.insert(tk.END, line)

def lugar_reina(fila, reinas, n, tablero_text):
    if fila == n:
        imprimir_tablero_text(tablero_text, reinas)
        return 1
    else:
        sol_total = 0
        for col in range(n):
            if no_valido(fila, col, reinas):
                reinas[fila] = col
                sol_total += lugar_reina(fila+1, reinas, n, tablero_text)
        return sol_total

def inicializar_reinas(n):
    return random.sample(range(n), n)

def n_reinas(n, tablero_text):
    reinas = inicializar_reinas(n)
    fila = 0
    return lugar_reina(fila, reinas, n, tablero_text)

def resolver_y_mostrar_solucion(n, tablero_text, tiempo_label):
    tablero_text.delete(1.0, tk.END)  
    try:
        start_time = time.time()
        soluciones = n_reinas(n, tablero_text)
        end_time = time.time()

        if soluciones == 0:
            messagebox.showinfo("Solución", "No hay soluciones para el tablero de " + str(n) + " reinas.")
        else:
            messagebox.showinfo("Solución", "Número total de soluciones: " + str(soluciones))

        tiempo_ejecucion = end_time - start_time
        tiempo_label.config(text=f"Tiempo de ejecución: {tiempo_ejecucion:.4f} segundos")

        # Agregar visualización gráfica del tiempo de ejecución
        plt.bar(["Soluciones", "Tiempo de ejecución"], [soluciones, tiempo_ejecucion])
        plt.ylabel("Valor")
        plt.title("Desempeño del algoritmo de N reinas")
        plt.show()

    except Exception as e:
        messagebox.showerror("Error", str(e))

def on_solve_button_click():
    try:
        n = int(entry.get())
        if n <= 0:
            raise ValueError("El número de reinas debe ser un entero positivo.")
        
        # Crear una etiqueta para mostrar el tiempo de ejecución
        tiempo_label = tk.Label(root, text="")
        tiempo_label.pack()

        resolver_y_mostrar_solucion(n, tablero_text, tiempo_label)
    except ValueError as e:
        messagebox.showerror("Error", str(e))

# Crear la interfaz gráfica
root = tk.Tk()
root.title("N-Reinas Solver")

label = tk.Label(root, text="Número de reinas:")
label.pack()

entry = tk.Entry(root)
entry.pack()

solve_button = tk.Button(root, text="Resolver", command=on_solve_button_click)
solve_button.pack()

# Widget Text para mostrar el tablero
tablero_text = tk.Text(root, height=8, width=16)
tablero_text.pack()

root.mainloop()



